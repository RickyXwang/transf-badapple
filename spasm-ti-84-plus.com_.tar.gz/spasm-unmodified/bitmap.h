#ifndef _BITMAP_H
#define _BITMAP_H

bool IsFileBitmap(FILE *file);
void handle_bitmap (FILE *file);

#endif